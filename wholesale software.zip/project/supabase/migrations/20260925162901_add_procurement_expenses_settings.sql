/*
# Procurement, Expenses, Reports & Settings Schema

## Purpose
Extends the wholesale POS with procurement (factory/supplier management and purchase orders),
expense tracking, business reports, and configurable settings.

## New Tables

### suppliers
- `id` (uuid, primary key)
- `name` (text, not null) — supplier/factory contact name
- `company` (text) — factory or company name
- `phone` (text)
- `email` (text)
- `address` (text)
- `payment_terms` (text, default 'Net 30') — e.g. Net 15, Net 30, COD
- `notes` (text)
- `created_at` (timestamptz, default now())

### purchase_orders
- `id` (uuid, primary key)
- `po_number` (text, unique, not null) — human-readable PO number (e.g. PO-0001)
- `supplier_id` (uuid, references suppliers)
- `subtotal` (numeric, not null, default 0)
- `tax_rate` (numeric, not null, default 0)
- `tax_amount` (numeric, not null, default 0)
- `shipping` (numeric, not null, default 0) — shipping/freight cost
- `total` (numeric, not null, default 0)
- `status` (text, not null, default 'draft') — draft, ordered, received, cancelled
- `notes` (text)
- `expected_date` (date) — expected delivery date
- `created_at` (timestamptz, default now())

### purchase_order_items
- `id` (uuid, primary key)
- `po_id` (uuid, references purchase_orders ON DELETE CASCADE)
- `product_id` (uuid, references products, nullable)
- `product_name` (text, not null) — snapshot
- `quantity` (numeric, not null) — units ordered
- `unit_cost` (numeric, not null) — cost per unit from supplier
- `line_total` (numeric, not null) — quantity * unit_cost

### expenses
- `id` (uuid, primary key)
- `category` (text, not null) — e.g. Rent, Utilities, Salaries, Transport, Marketing
- `description` (text, not null)
- `amount` (numeric, not null)
- `date` (date, not null)
- `created_at` (timestamptz, default now())

### settings
- `id` (uuid, primary key, default gen_random_uuid())
- `business_name` (text, default 'My Wholesale Business')
- `currency` (text, default 'USD')
- `default_tax_rate` (numeric, default 0)
- `tax_enabled` (boolean, default false)
- `phone` (text, default '')
- `email` (text, default '')
- `address` (text, default '')
- `updated_at` (timestamptz, default now())

## Security
- RLS enabled on all tables.
- All tables allow anon + authenticated full CRUD (single-tenant, no sign-in).
*/

-- Suppliers table
CREATE TABLE IF NOT EXISTS suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  company text DEFAULT '',
  phone text DEFAULT '',
  email text DEFAULT '',
  address text DEFAULT '',
  payment_terms text NOT NULL DEFAULT 'Net 30',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_suppliers" ON suppliers;
CREATE POLICY "anon_select_suppliers" ON suppliers FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_suppliers" ON suppliers;
CREATE POLICY "anon_insert_suppliers" ON suppliers FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_suppliers" ON suppliers;
CREATE POLICY "anon_update_suppliers" ON suppliers FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_suppliers" ON suppliers;
CREATE POLICY "anon_delete_suppliers" ON suppliers FOR DELETE
  TO anon, authenticated USING (true);

-- Purchase orders table
CREATE TABLE IF NOT EXISTS purchase_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  po_number text UNIQUE NOT NULL,
  supplier_id uuid REFERENCES suppliers(id) ON DELETE SET NULL,
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  tax_rate numeric(5,2) NOT NULL DEFAULT 0,
  tax_amount numeric(12,2) NOT NULL DEFAULT 0,
  shipping numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'draft',
  notes text DEFAULT '',
  expected_date date,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE purchase_orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_purchase_orders" ON purchase_orders;
CREATE POLICY "anon_select_purchase_orders" ON purchase_orders FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_purchase_orders" ON purchase_orders;
CREATE POLICY "anon_insert_purchase_orders" ON purchase_orders FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_purchase_orders" ON purchase_orders;
CREATE POLICY "anon_update_purchase_orders" ON purchase_orders FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_purchase_orders" ON purchase_orders;
CREATE POLICY "anon_delete_purchase_orders" ON purchase_orders FOR DELETE
  TO anon, authenticated USING (true);

-- Purchase order items table
CREATE TABLE IF NOT EXISTS purchase_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  po_id uuid NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  quantity numeric(12,2) NOT NULL,
  unit_cost numeric(12,2) NOT NULL,
  line_total numeric(12,2) NOT NULL
);

ALTER TABLE purchase_order_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_po_items" ON purchase_order_items;
CREATE POLICY "anon_select_po_items" ON purchase_order_items FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_po_items" ON purchase_order_items;
CREATE POLICY "anon_insert_po_items" ON purchase_order_items FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_po_items" ON purchase_order_items;
CREATE POLICY "anon_update_po_items" ON purchase_order_items FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_po_items" ON purchase_order_items;
CREATE POLICY "anon_delete_po_items" ON purchase_order_items FOR DELETE
  TO anon, authenticated USING (true);

-- Expenses table
CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL,
  description text NOT NULL,
  amount numeric(12,2) NOT NULL,
  date date NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_expenses" ON expenses;
CREATE POLICY "anon_select_expenses" ON expenses FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_expenses" ON expenses;
CREATE POLICY "anon_insert_expenses" ON expenses FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_expenses" ON expenses;
CREATE POLICY "anon_update_expenses" ON expenses FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_expenses" ON expenses;
CREATE POLICY "anon_delete_expenses" ON expenses FOR DELETE
  TO anon, authenticated USING (true);

-- Settings table (single row)
CREATE TABLE IF NOT EXISTS settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_name text NOT NULL DEFAULT 'My Wholesale Business',
  currency text NOT NULL DEFAULT 'USD',
  default_tax_rate numeric(5,2) NOT NULL DEFAULT 0,
  tax_enabled boolean NOT NULL DEFAULT false,
  phone text DEFAULT '',
  email text DEFAULT '',
  address text DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_settings" ON settings;
CREATE POLICY "anon_select_settings" ON settings FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_settings" ON settings;
CREATE POLICY "anon_insert_settings" ON settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_settings" ON settings;
CREATE POLICY "anon_update_settings" ON settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_settings" ON settings;
CREATE POLICY "anon_delete_settings" ON settings FOR DELETE
  TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_po_supplier ON purchase_orders(supplier_id);
CREATE INDEX IF NOT EXISTS idx_po_created ON purchase_orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_po_items_po ON purchase_order_items(po_id);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(date DESC);
CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses(category);

-- Insert default settings row if none exists
INSERT INTO settings (business_name, currency, default_tax_rate, tax_enabled)
SELECT 'My Wholesale Business', 'USD', 0, false
WHERE NOT EXISTS (SELECT 1 FROM settings);

-- Auto-generate PO numbers
CREATE OR REPLACE FUNCTION generate_po_number()
RETURNS text AS $$
DECLARE
  next_num int;
  new_number text;
BEGIN
  SELECT COALESCE(MAX(CAST(SUBSTRING(po_number FROM 4) AS int)), 0) + 1
  INTO next_num
  FROM purchase_orders
  WHERE po_number LIKE 'PO-%';

  new_number := 'PO-' || lpad(next_num::text, 4, '0');
  RETURN new_number;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
