import { useEffect, useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  ShoppingBag,
  Package,
  Award,
  Calendar,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatCurrency } from '@/components/ui';

interface TopProduct {
  product_name: string;
  total_qty: number;
  total_revenue: number;
}

interface TopCustomer {
  customer_name: string;
  total_spent: number;
  order_count: number;
}

export default function Reports() {
  const [period, setPeriod] = useState<'7d' | '30d' | '90d' | 'all'>('30d');
  const [loading, setLoading] = useState(true);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [totalCost, setTotalCost] = useState(0);
  const [totalProfit, setTotalProfit] = useState(0);
  const [orderCount, setOrderCount] = useState(0);
  const [totalItemsSold, setTotalItemsSold] = useState(0);
  const [topProducts, setTopProducts] = useState<TopProduct[]>([]);
  const [topCustomers, setTopCustomers] = useState<TopCustomer[]>([]);
  const [dailySales, setDailySales] = useState<{ date: string; total: number }[]>([]);
  const [totalExpenses, setTotalExpenses] = useState(0);
  const [netProfit, setNetProfit] = useState(0);

  useEffect(() => {
    fetchReportData();
  }, [period]);

  const fetchReportData = async () => {
    setLoading(true);

    let dateFilter: string | null = null;
    if (period !== 'all') {
      const days = parseInt(period);
      const d = new Date();
      d.setDate(d.getDate() - days);
      dateFilter = d.toISOString();
    }

    // Fetch orders
    let ordersQuery = supabase.from('orders').select('id, total, created_at').eq('status', 'completed');
    if (dateFilter) ordersQuery = ordersQuery.gte('created_at', dateFilter);
    const { data: orders } = await ordersQuery;

    // Fetch order items with product cost
    let itemsQuery = supabase
      .from('order_items')
      .select('product_id, product_name, quantity, unit_price, line_total, order:orders!inner(status, created_at)')
      .eq('order.status', 'completed');
    if (dateFilter) itemsQuery = itemsQuery.gte('order.created_at', dateFilter);
    const { data: items } = await itemsQuery;

    // Fetch product costs
    const productIds = (items || []).map((i: any) => i.product_id).filter(Boolean);
    const { data: products } = await supabase
      .from('products')
      .select('id, cost_price')
      .in('id', productIds.length > 0 ? productIds : ['00000000-0000-0000-0000-000000000000']);

    const costMap = new Map<string, number>();
    (products || []).forEach((p: any) => costMap.set(p.id, Number(p.cost_price)));

    // Fetch expenses
    let expensesQuery = supabase.from('expenses').select('amount, date');
    if (dateFilter) {
      const d = new Date(dateFilter);
      expensesQuery = expensesQuery.gte('date', d.toISOString().split('T')[0]);
    }
    const { data: expenses } = await expensesQuery;

    // Calculate metrics
    const revenue = (orders || []).reduce((sum, o) => sum + Number(o.total), 0);
    setTotalRevenue(revenue);
    setOrderCount((orders || []).length);

    let cost = 0;
    let itemsSold = 0;
    const productMap = new Map<string, TopProduct>();

    (items || []).forEach((item: any) => {
      const qty = Number(item.quantity);
      const revenue = Number(item.line_total);
      const unitCost = item.product_id ? costMap.get(item.product_id) || 0 : 0;
      cost += qty * unitCost;
      itemsSold += qty;

      const existing = productMap.get(item.product_name);
      if (existing) {
        existing.total_qty += qty;
        existing.total_revenue += revenue;
      } else {
        productMap.set(item.product_name, { product_name: item.product_name, total_qty: qty, total_revenue: revenue });
      }
    });

    setTotalCost(cost);
    setTotalItemsSold(itemsSold);
    setTotalProfit(revenue - cost);

    const expenseTotal = (expenses || []).reduce((sum, e) => sum + Number(e.amount), 0);
    setTotalExpenses(expenseTotal);
    setNetProfit(revenue - cost - expenseTotal);

    // Top products
    const topProds = Array.from(productMap.values())
      .sort((a, b) => b.total_revenue - a.total_revenue)
      .slice(0, 5);
    setTopProducts(topProds);

    // Top customers
    let custQuery = supabase
      .from('orders')
      .select('total, customer:customers(name)')
      .eq('status', 'completed');
    if (dateFilter) custQuery = custQuery.gte('created_at', dateFilter);
    const { data: custOrders } = await custQuery;

    const custMap = new Map<string, TopCustomer>();
    (custOrders || []).forEach((o: any) => {
      const name = o.customer?.name || 'Walk-in';
      const existing = custMap.get(name);
      if (existing) {
        existing.total_spent += Number(o.total);
        existing.order_count += 1;
      } else {
        custMap.set(name, { customer_name: name, total_spent: Number(o.total), order_count: 1 });
      }
    });
    setTopCustomers(Array.from(custMap.values()).sort((a, b) => b.total_spent - a.total_spent).slice(0, 5));

    // Daily sales for chart
    if (period === '7d' || period === '30d') {
      const days = parseInt(period);
      const salesByDay = new Map<string, number>();
      (orders || []).forEach((o) => {
        const day = new Date(o.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        salesByDay.set(day, (salesByDay.get(day) || 0) + Number(o.total));
      });
      const chartData: { date: string; total: number }[] = [];
      for (let i = days - 1; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const day = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        chartData.push({ date: day, total: salesByDay.get(day) || 0 });
      }
      setDailySales(chartData);
    } else {
      setDailySales([]);
    }

    setLoading(false);
  };

  const maxSale = Math.max(...dailySales.map((d) => d.total), 1);

  const periods = [
    { value: '7d', label: '7 Days' },
    { value: '30d', label: '30 Days' },
    { value: '90d', label: '90 Days' },
    { value: 'all', label: 'All Time' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Reports & Analytics</h1>
          <p className="text-slate-500 mt-1">Track revenue, profit margins, and business performance</p>
        </div>
        <div className="flex gap-2 bg-white rounded-lg border border-slate-200 p-1">
          {periods.map((p) => (
            <button
              key={p.value}
              onClick={() => setPeriod(p.value as any)}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                period === p.value ? 'bg-emerald-500 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Key metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center mb-3">
            <DollarSign className="w-5 h-5 text-emerald-500" />
          </div>
          <p className="text-2xl font-bold text-slate-800">{formatCurrency(totalRevenue)}</p>
          <p className="text-sm text-slate-500 mt-1">Total Revenue</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-slate-200">
          <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center mb-3">
            <TrendingUp className="w-5 h-5 text-blue-500" />
          </div>
          <p className="text-2xl font-bold text-slate-800">{formatCurrency(totalProfit)}</p>
          <p className="text-sm text-slate-500 mt-1">Gross Profit</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-slate-200">
          <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center mb-3">
            <TrendingDown className="w-5 h-5 text-purple-500" />
          </div>
          <p className="text-2xl font-bold text-slate-800">{formatCurrency(netProfit)}</p>
          <p className="text-sm text-slate-500 mt-1">Net Profit</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-slate-200">
          <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center mb-3">
            <ShoppingBag className="w-5 h-5 text-amber-500" />
          </div>
          <p className="text-2xl font-bold text-slate-800">{orderCount}</p>
          <p className="text-sm text-slate-500 mt-1">Orders</p>
        </div>
      </div>

      {/* Profit breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-4 h-4 text-emerald-500" />
            <p className="text-sm font-medium text-slate-600">Revenue</p>
          </div>
          <p className="text-xl font-bold text-slate-800">{formatCurrency(totalRevenue)}</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-slate-200">
          <div className="flex items-center gap-2 mb-2">
            <Package className="w-4 h-4 text-blue-500" />
            <p className="text-sm font-medium text-slate-600">Cost of Goods</p>
          </div>
          <p className="text-xl font-bold text-slate-800">{formatCurrency(totalCost)}</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-slate-200">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="w-4 h-4 text-orange-500" />
            <p className="text-sm font-medium text-slate-600">Operating Expenses</p>
          </div>
          <p className="text-xl font-bold text-slate-800">{formatCurrency(totalExpenses)}</p>
        </div>
      </div>

      {/* Sales chart */}
      {dailySales.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h2 className="font-bold text-slate-800 mb-4">Daily Sales Trend</h2>
          <div className="flex items-end gap-1 h-48">
            {dailySales.map((d, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1 group">
                <div className="w-full relative flex-1 flex items-end">
                  <div
                    className="w-full bg-emerald-400 rounded-t-md hover:bg-emerald-500 transition-colors cursor-pointer"
                    style={{ height: `${(d.total / maxSale) * 100}%`, minHeight: d.total > 0 ? '4px' : '0' }}
                  >
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                      {formatCurrency(d.total)}
                    </div>
                  </div>
                </div>
                {i % Math.ceil(dailySales.length / 7) === 0 && (
                  <span className="text-xs text-slate-400">{d.date}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top products */}
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="flex items-center gap-2 px-6 py-4 border-b border-slate-200">
            <Award className="w-5 h-5 text-amber-500" />
            <h2 className="font-bold text-slate-800">Top Products by Revenue</h2>
          </div>
          <div className="divide-y divide-slate-100">
            {topProducts.length === 0 ? (
              <p className="px-6 py-8 text-sm text-slate-400 text-center">No sales data yet</p>
            ) : (
              topProducts.map((p, i) => (
                <div key={i} className="flex items-center justify-between px-6 py-3">
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-sm font-bold text-slate-500">
                      {i + 1}
                    </span>
                    <div>
                      <p className="font-medium text-slate-800 text-sm">{p.product_name}</p>
                      <p className="text-xs text-slate-400">{p.total_qty} units sold</p>
                    </div>
                  </div>
                  <span className="font-semibold text-slate-700 text-sm">{formatCurrency(p.total_revenue)}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Top customers */}
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="flex items-center gap-2 px-6 py-4 border-b border-slate-200">
            <Award className="w-5 h-5 text-blue-500" />
            <h2 className="font-bold text-slate-800">Top Customers by Spending</h2>
          </div>
          <div className="divide-y divide-slate-100">
            {topCustomers.length === 0 ? (
              <p className="px-6 py-8 text-sm text-slate-400 text-center">No customer data yet</p>
            ) : (
              topCustomers.map((c, i) => (
                <div key={i} className="flex items-center justify-between px-6 py-3">
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-sm font-bold text-slate-500">
                      {i + 1}
                    </span>
                    <div>
                      <p className="font-medium text-slate-800 text-sm">{c.customer_name}</p>
                      <p className="text-xs text-slate-400">{c.order_count} order(s)</p>
                    </div>
                  </div>
                  <span className="font-semibold text-slate-700 text-sm">{formatCurrency(c.total_spent)}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
