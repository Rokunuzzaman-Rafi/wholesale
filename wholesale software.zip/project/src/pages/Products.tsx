import { useEffect, useState } from 'react';
import { Plus, Search, Pencil, Trash2, Package } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Product } from '@/types';
import { Modal, Input, Select, Button, formatCurrency } from '@/components/ui';

const emptyForm = {
  sku: '',
  name: '',
  category: 'General',
  unit: 'pcs',
  cost_price: '0',
  sell_price: '0',
  stock_qty: '0',
  reorder_level: '10',
};

const units = ['pcs', 'box', 'kg', 'g', 'L', 'm', 'pack', 'roll', 'set'];

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('name', { ascending: true });
    if (!error && data) setProducts(data as Product[]);
    setLoading(false);
  };

  const categories = ['all', ...Array.from(new Set(products.map((p) => p.category)))];

  const filtered = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase());
    const matchesCat = filterCategory === 'all' || p.category === filterCategory;
    return matchesSearch && matchesCat;
  });

  const openAdd = () => {
    setEditId(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const openEdit = (p: Product) => {
    setEditId(p.id);
    setForm({
      sku: p.sku,
      name: p.name,
      category: p.category,
      unit: p.unit,
      cost_price: String(p.cost_price),
      sell_price: String(p.sell_price),
      stock_qty: String(p.stock_qty),
      reorder_level: String(p.reorder_level),
    });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.sku.trim() || !form.name.trim()) return;
    setSaving(true);

    const payload = {
      sku: form.sku.trim(),
      name: form.name.trim(),
      category: form.category,
      unit: form.unit,
      cost_price: parseFloat(form.cost_price) || 0,
      sell_price: parseFloat(form.sell_price) || 0,
      stock_qty: parseFloat(form.stock_qty) || 0,
      reorder_level: parseFloat(form.reorder_level) || 0,
    };

    if (editId) {
      const { error } = await supabase.from('products').update(payload).eq('id', editId);
      if (error) {
        alert('Error updating product: ' + error.message);
        setSaving(false);
        return;
      }
    } else {
      const { error } = await supabase.from('products').insert(payload);
      if (error) {
        alert('Error adding product: ' + error.message);
        setSaving(false);
        return;
      }
    }

    setSaving(false);
    setModalOpen(false);
    fetchProducts();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('products').delete().eq('id', deleteId);
    if (error) {
      alert('Error deleting product: ' + error.message);
      return;
    }
    setDeleteId(null);
    fetchProducts();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Products</h1>
          <p className="text-slate-500 mt-1">Manage your inventory and pricing</p>
        </div>
        <Button onClick={openAdd}>
          <Plus className="w-4 h-4 inline mr-1" /> Add Product
        </Button>
      </div>

      {/* Search & filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name or SKU..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none text-slate-800"
          />
        </div>
        <select
          value={filterCategory}
          onChange={(e) => setFilterCategory(e.target.value)}
          className="px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none bg-white text-slate-800"
        >
          {categories.map((c) => (
            <option key={c} value={c}>
              {c === 'all' ? 'All Categories' : c}
            </option>
          ))}
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">SKU</th>
                <th className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Name</th>
                <th className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider hidden md:table-cell">Category</th>
                <th className="text-right px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Price</th>
                <th className="text-right px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Stock</th>
                <th className="text-center px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center">
                    <Package className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                    <p className="text-slate-400">No products found</p>
                  </td>
                </tr>
              ) : (
                filtered.map((p) => {
                  const lowStock = p.stock_qty <= p.reorder_level;
                  return (
                    <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 text-sm font-medium text-slate-600">{p.sku}</td>
                      <td className="px-6 py-4 text-sm font-medium text-slate-800">{p.name}</td>
                      <td className="px-6 py-4 text-sm text-slate-500 hidden md:table-cell">{p.category}</td>
                      <td className="px-6 py-4 text-sm text-slate-700 text-right font-medium">
                        {formatCurrency(p.sell_price)}
                        <span className="text-xs text-slate-400 block">/{p.unit}</span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-full text-xs font-medium ${
                            p.stock_qty <= 0
                              ? 'bg-red-100 text-red-700'
                              : lowStock
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-emerald-100 text-emerald-700'
                          }`}
                        >
                          {p.stock_qty} {p.unit}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => openEdit(p)}
                            className="p-2 rounded-lg hover:bg-slate-200 text-slate-500 transition-colors"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteId(p.id)}
                            className="p-2 rounded-lg hover:bg-red-100 text-red-500 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? 'Edit Product' : 'Add Product'}>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="SKU" value={form.sku} onChange={(v) => setForm({ ...form, sku: v })} placeholder="e.g. WHS-001" />
            <Select
              label="Unit"
              value={form.unit}
              onChange={(v) => setForm({ ...form, unit: v })}
              options={units.map((u) => ({ value: u, label: u }))}
            />
          </div>
          <Input label="Product Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} placeholder="e.g. Cardboard Box Large" />
          <Input label="Category" value={form.category} onChange={(v) => setForm({ ...form, category: v })} placeholder="e.g. Packaging" />
          <div className="grid grid-cols-2 gap-4">
            <Input label="Cost Price" type="number" step="0.01" value={form.cost_price} onChange={(v) => setForm({ ...form, cost_price: v })} />
            <Input label="Sell Price" type="number" step="0.01" value={form.sell_price} onChange={(v) => setForm({ ...form, sell_price: v })} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Stock Quantity" type="number" step="0.01" value={form.stock_qty} onChange={(v) => setForm({ ...form, stock_qty: v })} />
            <Input label="Reorder Level" type="number" step="0.01" value={form.reorder_level} onChange={(v) => setForm({ ...form, reorder_level: v })} />
          </div>
          <div className="flex gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)} className="flex-1">
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={saving} className="flex-1">
              {saving ? 'Saving...' : editId ? 'Update Product' : 'Add Product'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Delete confirm */}
      <Modal open={!!deleteId} onClose={() => setDeleteId(null)} title="Delete Product" maxWidth="max-w-sm">
        <p className="text-slate-600 mb-6">Are you sure you want to delete this product? This cannot be undone.</p>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={() => setDeleteId(null)} className="flex-1">
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDelete} className="flex-1">
            Delete
          </Button>
        </div>
      </Modal>
    </div>
  );
}
