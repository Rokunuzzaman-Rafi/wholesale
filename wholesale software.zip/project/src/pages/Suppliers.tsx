import { useEffect, useState } from 'react';
import { Plus, Search, Pencil, Trash2, Factory, Phone, Mail, Building2, CreditCard } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Supplier } from '@/types';
import { Modal, Input, Select, Button, formatDate } from '@/components/ui';

const emptyForm = {
  name: '',
  company: '',
  phone: '',
  email: '',
  address: '',
  payment_terms: 'Net 30',
  notes: '',
};

const paymentTerms = ['COD', 'Net 7', 'Net 15', 'Net 30', 'Net 45', 'Net 60', 'Prepaid'];

export default function Suppliers() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => {
    fetchSuppliers();
  }, []);

  const fetchSuppliers = async () => {
    const { data } = await supabase.from('suppliers').select('*').order('name', { ascending: true });
    if (data) setSuppliers(data as Supplier[]);
    setLoading(false);
  };

  const filtered = suppliers.filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.company.toLowerCase().includes(search.toLowerCase()) ||
      s.phone.includes(search)
  );

  const openAdd = () => {
    setEditId(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const openEdit = (s: Supplier) => {
    setEditId(s.id);
    setForm({
      name: s.name,
      company: s.company,
      phone: s.phone,
      email: s.email,
      address: s.address,
      payment_terms: s.payment_terms,
      notes: s.notes,
    });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    const payload = {
      name: form.name.trim(),
      company: form.company.trim(),
      phone: form.phone.trim(),
      email: form.email.trim(),
      address: form.address.trim(),
      payment_terms: form.payment_terms,
      notes: form.notes.trim(),
    };

    if (editId) {
      const { error } = await supabase.from('suppliers').update(payload).eq('id', editId);
      if (error) { alert('Error: ' + error.message); setSaving(false); return; }
    } else {
      const { error } = await supabase.from('suppliers').insert(payload);
      if (error) { alert('Error: ' + error.message); setSaving(false); return; }
    }

    setSaving(false);
    setModalOpen(false);
    fetchSuppliers();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('suppliers').delete().eq('id', deleteId);
    if (error) { alert('Error: ' + error.message); return; }
    setDeleteId(null);
    fetchSuppliers();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Suppliers</h1>
          <p className="text-slate-500 mt-1">Manage factories and vendors you procure from</p>
        </div>
        <Button onClick={openAdd}>
          <Plus className="w-4 h-4 inline mr-1" /> Add Supplier
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          placeholder="Search by name, company, or phone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none text-slate-800"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.length === 0 ? (
          <div className="col-span-full bg-white rounded-2xl border border-slate-200 p-12 text-center">
            <Factory className="w-12 h-12 text-slate-300 mx-auto mb-2" />
            <p className="text-slate-400">No suppliers found</p>
          </div>
        ) : (
          filtered.map((s) => (
            <div key={s.id} className="bg-white rounded-2xl border border-slate-200 p-5 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-lg">
                    {s.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800">{s.name}</h3>
                    {s.company && (
                      <p className="text-xs text-slate-500 flex items-center gap-1">
                        <Building2 className="w-3 h-3" /> {s.company}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => openEdit(s)} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 transition-colors">
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button onClick={() => setDeleteId(s.id)} className="p-1.5 rounded-lg hover:bg-red-100 text-red-400 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                {s.phone && (
                  <p className="text-sm text-slate-600 flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400" /> {s.phone}
                  </p>
                )}
                {s.email && (
                  <p className="text-sm text-slate-600 flex items-center gap-2 truncate">
                    <Mail className="w-3.5 h-3.5 text-slate-400" /> {s.email}
                  </p>
                )}
                <p className="text-sm text-slate-600 flex items-center gap-2">
                  <CreditCard className="w-3.5 h-3.5 text-slate-400" /> {s.payment_terms}
                </p>
                {s.address && <p className="text-sm text-slate-400">{s.address}</p>}
                <p className="text-xs text-slate-300 pt-1">Added {formatDate(s.created_at)}</p>
              </div>
            </div>
          ))
        )}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? 'Edit Supplier' : 'Add Supplier'}>
        <div className="space-y-4">
          <Input label="Contact Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} placeholder="e.g. Factory Rep" />
          <Input label="Company / Factory" value={form.company} onChange={(v) => setForm({ ...form, company: v })} placeholder="e.g. ABC Manufacturing" />
          <div className="grid grid-cols-2 gap-4">
            <Input label="Phone" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} placeholder="555-0100" />
            <Input label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} placeholder="factory@example.com" />
          </div>
          <Input label="Address" value={form.address} onChange={(v) => setForm({ ...form, address: v })} placeholder="Factory address" />
          <Select
            label="Payment Terms"
            value={form.payment_terms}
            onChange={(v) => setForm({ ...form, payment_terms: v })}
            options={paymentTerms.map((t) => ({ value: t, label: t }))}
          />
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Notes</label>
            <textarea
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              rows={2}
              placeholder="Any notes about this supplier..."
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800 resize-none"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)} className="flex-1">Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="flex-1">
              {saving ? 'Saving...' : editId ? 'Update' : 'Add Supplier'}
            </Button>
          </div>
        </div>
      </Modal>

      <Modal open={!!deleteId} onClose={() => setDeleteId(null)} title="Delete Supplier" maxWidth="max-w-sm">
        <p className="text-slate-600 mb-6">Are you sure you want to delete this supplier?</p>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={() => setDeleteId(null)} className="flex-1">Cancel</Button>
          <Button variant="danger" onClick={handleDelete} className="flex-1">Delete</Button>
        </div>
      </Modal>
    </div>
  );
}
