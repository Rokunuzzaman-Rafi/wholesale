import { useEffect, useState } from 'react';
import { Plus, Search, Trash2, Wallet, Pencil } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Expense } from '@/types';
import { Modal, Input, Select, Button, formatCurrency } from '@/components/ui';

const categories = [
  'Rent',
  'Utilities',
  'Salaries',
  'Transport',
  'Marketing',
  'Supplies',
  'Maintenance',
  'Insurance',
  'Taxes',
  'Other',
];

const emptyForm = {
  category: 'Rent',
  description: '',
  amount: '0',
  date: new Date().toISOString().split('T')[0],
};

export default function Expenses() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [totalAmount, setTotalAmount] = useState(0);
  const [categoryTotals, setCategoryTotals] = useState<{ category: string; amount: number }[]>([]);

  useEffect(() => {
    fetchExpenses();
  }, []);

  const fetchExpenses = async () => {
    const { data } = await supabase.from('expenses').select('*').order('date', { ascending: false });
    if (data) {
      setExpenses(data as Expense[]);
      const total = data.reduce((sum, e) => sum + Number(e.amount), 0);
      setTotalAmount(total);
      const catMap = new Map<string, number>();
      data.forEach((e) => {
        catMap.set(e.category, (catMap.get(e.category) || 0) + Number(e.amount));
      });
      setCategoryTotals(Array.from(catMap.entries()).map(([category, amount]) => ({ category, amount })).sort((a, b) => b.amount - a.amount));
    }
    setLoading(false);
  };

  const filtered = expenses.filter((e) => {
    const matchesSearch = e.description.toLowerCase().includes(search.toLowerCase());
    const matchesCat = filterCategory === 'all' || e.category === filterCategory;
    return matchesSearch && matchesCat;
  });

  const filteredTotal = filtered.reduce((sum, e) => sum + Number(e.amount), 0);

  const openAdd = () => {
    setEditId(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const openEdit = (e: Expense) => {
    setEditId(e.id);
    setForm({
      category: e.category,
      description: e.description,
      amount: String(e.amount),
      date: e.date,
    });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.description.trim() || !form.amount) return;
    setSaving(true);
    const payload = {
      category: form.category,
      description: form.description.trim(),
      amount: parseFloat(form.amount) || 0,
      date: form.date,
    };

    if (editId) {
      const { error } = await supabase.from('expenses').update(payload).eq('id', editId);
      if (error) { alert('Error: ' + error.message); setSaving(false); return; }
    } else {
      const { error } = await supabase.from('expenses').insert(payload);
      if (error) { alert('Error: ' + error.message); setSaving(false); return; }
    }

    setSaving(false);
    setModalOpen(false);
    fetchExpenses();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('expenses').delete().eq('id', deleteId);
    if (error) { alert('Error: ' + error.message); return; }
    setDeleteId(null);
    fetchExpenses();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Expenses</h1>
          <p className="text-slate-500 mt-1">Track your business operating expenses</p>
        </div>
        <Button onClick={openAdd}>
          <Plus className="w-4 h-4 inline mr-1" /> Add Expense
        </Button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200">
          <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center mb-3">
            <Wallet className="w-5 h-5 text-red-500" />
          </div>
          <p className="text-xl font-bold text-slate-800">{formatCurrency(totalAmount)}</p>
          <p className="text-sm text-slate-500 mt-1">Total Expenses</p>
        </div>
        {categoryTotals.slice(0, 3).map((ct) => (
          <div key={ct.category} className="bg-white rounded-2xl p-5 border border-slate-200">
            <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center mb-3">
              <Wallet className="w-5 h-5 text-slate-400" />
            </div>
            <p className="text-xl font-bold text-slate-800">{formatCurrency(ct.amount)}</p>
            <p className="text-sm text-slate-500 mt-1">{ct.category}</p>
          </div>
        ))}
      </div>

      {/* Search & filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search expenses..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none text-slate-800"
          />
        </div>
        <select
          value={filterCategory}
          onChange={(e) => setFilterCategory(e.target.value)}
          className="px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none bg-white text-slate-800"
        >
          <option value="all">All Categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      <div className="flex justify-between items-center px-2">
        <p className="text-sm text-slate-500">{filtered.length} expense(s) shown</p>
        <p className="text-sm font-medium text-slate-700">Filtered total: {formatCurrency(filteredTotal)}</p>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Date</th>
                <th className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Category</th>
                <th className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Description</th>
                <th className="text-right px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Amount</th>
                <th className="text-center px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center">
                    <Wallet className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                    <p className="text-slate-400">No expenses found</p>
                  </td>
                </tr>
              ) : (
                filtered.map((e) => (
                  <tr key={e.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 text-sm text-slate-500">
                      {new Date(e.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-600">
                        {e.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-slate-700">{e.description}</td>
                    <td className="px-6 py-4 text-sm font-bold text-red-500 text-right">-{formatCurrency(Number(e.amount))}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-center gap-2">
                        <button onClick={() => openEdit(e)} className="p-2 rounded-lg hover:bg-slate-200 text-slate-500 transition-colors">
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button onClick={() => setDeleteId(e.id)} className="p-2 rounded-lg hover:bg-red-100 text-red-500 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? 'Edit Expense' : 'Add Expense'}>
        <div className="space-y-4">
          <Select
            label="Category"
            value={form.category}
            onChange={(v) => setForm({ ...form, category: v })}
            options={categories.map((c) => ({ value: c, label: c }))}
          />
          <Input label="Description" value={form.description} onChange={(v) => setForm({ ...form, description: v })} placeholder="e.g. Monthly warehouse rent" />
          <div className="grid grid-cols-2 gap-4">
            <Input label="Amount" type="number" step="0.01" value={form.amount} onChange={(v) => setForm({ ...form, amount: v })} />
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Date</label>
              <input
                type="date"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800"
              />
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)} className="flex-1">Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="flex-1">
              {saving ? 'Saving...' : editId ? 'Update' : 'Add Expense'}
            </Button>
          </div>
        </div>
      </Modal>

      <Modal open={!!deleteId} onClose={() => setDeleteId(null)} title="Delete Expense" maxWidth="max-w-sm">
        <p className="text-slate-600 mb-6">Are you sure you want to delete this expense?</p>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={() => setDeleteId(null)} className="flex-1">Cancel</Button>
          <Button variant="danger" onClick={handleDelete} className="flex-1">Delete</Button>
        </div>
      </Modal>
    </div>
  );
}
