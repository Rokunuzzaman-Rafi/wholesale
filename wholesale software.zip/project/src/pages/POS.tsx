import { useEffect, useState, useCallback } from 'react';
import {
  Search,
  Plus,
  Minus,
  Trash2,
  ShoppingCart,
  CheckCircle,
  X,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Product, Customer, CartItem } from '@/types';
import { Select, Button, formatCurrency } from '@/components/ui';
import type { PageId } from '@/components/Layout';

interface POSProps {
  onNavigate: (page: PageId) => void;
}

export default function POS({ onNavigate }: POSProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState('walkin');
  const [taxRate, setTaxRate] = useState('0');
  const [discount, setDiscount] = useState('0');
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [notes, setNotes] = useState('');
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [successOrder, setSuccessOrder] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const [prodRes, custRes] = await Promise.all([
      supabase.from('products').select('*').order('name', { ascending: true }),
      supabase.from('customers').select('*').order('name', { ascending: true }),
    ]);
    if (prodRes.data) setProducts(prodRes.data as Product[]);
    if (custRes.data) setCustomers(custRes.data as Customer[]);
    setLoading(false);
  };

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase())
  );

  const addToCart = (product: Product) => {
    if (product.stock_qty <= 0) return;
    const existing = cart.find((c) => c.product.id === product.id);
    if (existing) {
      if (existing.quantity >= product.stock_qty) return;
      setCart(cart.map((c) =>
        c.product.id === product.id ? { ...c, quantity: c.quantity + 1 } : c
      ));
    } else {
      setCart([...cart, { product, quantity: 1 }]);
    }
  };

  const updateQty = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((c) => {
          if (c.product.id !== productId) return c;
          const newQty = c.quantity + delta;
          if (newQty > c.product.stock_qty) return c;
          return { ...c, quantity: newQty };
        })
        .filter((c) => c.quantity > 0)
    );
  };

  const setQty = (productId: string, qty: number) => {
    setCart((prev) =>
      prev
        .map((c) => {
          if (c.product.id !== productId) return c;
          const clamped = Math.min(Math.max(0, qty), c.product.stock_qty);
          return { ...c, quantity: clamped };
        })
        .filter((c) => c.quantity > 0)
    );
  };

  const removeFromCart = (productId: string) => {
    setCart(cart.filter((c) => c.product.id !== productId));
  };

  const subtotal = cart.reduce((sum, c) => sum + c.quantity * c.product.sell_price, 0);
  const taxAmount = (subtotal * (parseFloat(taxRate) || 0)) / 100;
  const discountAmount = parseFloat(discount) || 0;
  const total = Math.max(0, subtotal + taxAmount - discountAmount);

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setProcessing(true);

    // Generate order number
    const { data: orderNum } = await supabase.rpc('generate_order_number');
    if (!orderNum) {
      alert('Failed to generate order number');
      setProcessing(false);
      return;
    }

    const orderData = {
      order_number: orderNum,
      customer_id: selectedCustomer === 'walkin' ? null : selectedCustomer,
      subtotal: subtotal,
      tax_rate: parseFloat(taxRate) || 0,
      tax_amount: taxAmount,
      discount: discountAmount,
      total: total,
      payment_method: paymentMethod,
      status: 'completed',
      notes: notes,
    };

    const { data: orderResult, error: orderError } = await supabase
      .from('orders')
      .insert(orderData)
      .select('id')
      .single();

    if (orderError || !orderResult) {
      alert('Error creating order: ' + (orderError?.message || 'Unknown error'));
      setProcessing(false);
      return;
    }

    // Insert order items
    const items = cart.map((c) => ({
      order_id: orderResult.id,
      product_id: c.product.id,
      product_name: c.product.name,
      quantity: c.quantity,
      unit_price: c.product.sell_price,
      line_total: c.quantity * c.product.sell_price,
    }));

    const { error: itemsError } = await supabase.from('order_items').insert(items);
    if (itemsError) {
      alert('Error saving order items: ' + itemsError.message);
      setProcessing(false);
      return;
    }

    // Decrement stock
    for (const item of cart) {
      const newStock = item.product.stock_qty - item.quantity;
      await supabase
        .from('products')
        .update({ stock_qty: newStock })
        .eq('id', item.product.id);
    }

    setProcessing(false);
    setSuccessOrder(orderNum);
    setCart([]);
    setSelectedCustomer('walkin');
    setTaxRate('0');
    setDiscount('0');
    setNotes('');
    setCheckoutOpen(false);
    fetchData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (successOrder) {
    return (
      <div className="flex flex-col items-center justify-center h-96 text-center">
        <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mb-4">
          <CheckCircle className="w-12 h-12 text-emerald-500" />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Sale Complete!</h2>
        <p className="text-slate-500 mb-1">Order <span className="font-semibold text-slate-700">{successOrder}</span> has been recorded</p>
        <p className="text-slate-400 text-sm mb-6">Inventory has been updated automatically</p>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={() => { setSuccessOrder(null); onNavigate('orders'); }}>
            View Orders
          </Button>
          <Button onClick={() => setSuccessOrder(null)}>
            New Sale
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">New Sale</h1>
        <p className="text-slate-500 mt-1">Select products and checkout</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Product grid */}
        <div className="lg:col-span-2 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search products by name or SKU..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none text-slate-800"
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
            {filteredProducts.map((p) => {
              const outOfStock = p.stock_qty <= 0;
              return (
                <button
                  key={p.id}
                  onClick={() => addToCart(p)}
                  disabled={outOfStock}
                  className={`text-left bg-white rounded-xl border p-3 transition-all ${
                    outOfStock
                      ? 'border-slate-200 opacity-50 cursor-not-allowed'
                      : 'border-slate-200 hover:border-emerald-400 hover:shadow-md active:scale-95'
                  }`}
                >
                  <div className="flex items-start justify-between mb-1">
                    <span className="text-xs font-medium text-slate-400">{p.sku}</span>
                    <span
                      className={`text-xs px-1.5 py-0.5 rounded-full ${
                        outOfStock
                          ? 'bg-red-100 text-red-600'
                          : p.stock_qty <= p.reorder_level
                          ? 'bg-amber-100 text-amber-600'
                          : 'bg-emerald-100 text-emerald-600'
                      }`}
                    >
                      {p.stock_qty} {p.unit}
                    </span>
                  </div>
                  <p className="font-medium text-slate-800 text-sm leading-tight mb-2 line-clamp-2">{p.name}</p>
                  <p className="font-bold text-emerald-600">{formatCurrency(p.sell_price)}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Cart sidebar */}
        <div className="lg:sticky lg:top-4 lg:self-start">
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center gap-2 px-5 py-4 border-b border-slate-200 bg-slate-50">
              <ShoppingCart className="w-5 h-5 text-emerald-500" />
              <h2 className="font-bold text-slate-800">Cart</h2>
              {cart.length > 0 && (
                <span className="ml-auto text-sm text-slate-400">{cart.length} item(s)</span>
              )}
            </div>

            <div className="max-h-[40vh] overflow-y-auto divide-y divide-slate-100">
              {cart.length === 0 ? (
                <div className="px-5 py-12 text-center">
                  <ShoppingCart className="w-10 h-10 text-slate-200 mx-auto mb-2" />
                  <p className="text-sm text-slate-400">Cart is empty</p>
                  <p className="text-xs text-slate-300">Click a product to add it</p>
                </div>
              ) : (
                cart.map((c) => (
                  <div key={c.product.id} className="px-5 py-3 flex items-center gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-800 truncate">{c.product.name}</p>
                      <p className="text-xs text-slate-400">{formatCurrency(c.product.sell_price)} / {c.product.unit}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => updateQty(c.product.id, -1)}
                        className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <input
                        type="number"
                        value={c.quantity}
                        onChange={(e) => setQty(c.product.id, parseInt(e.target.value) || 0)}
                        className="w-12 text-center text-sm font-medium border border-slate-200 rounded-lg py-1 outline-none focus:ring-1 focus:ring-emerald-500"
                      />
                      <button
                        onClick={() => updateQty(c.product.id, 1)}
                        disabled={c.quantity >= c.product.stock_qty}
                        className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 disabled:opacity-40"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => removeFromCart(c.product.id)}
                        className="w-7 h-7 rounded-lg hover:bg-red-100 flex items-center justify-center text-red-400 ml-1"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Totals */}
            <div className="border-t border-slate-200 px-5 py-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Subtotal</span>
                <span className="font-medium text-slate-700">{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Tax ({taxRate || 0}%)</span>
                <span className="font-medium text-slate-700">{formatCurrency(taxAmount)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Discount</span>
                <span className="font-medium text-slate-700">-{formatCurrency(discountAmount)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-100">
                <span className="font-bold text-slate-800">Total</span>
                <span className="font-bold text-emerald-600 text-lg">{formatCurrency(total)}</span>
              </div>
              <Button
                onClick={() => setCheckoutOpen(true)}
                disabled={cart.length === 0}
                className="w-full mt-2"
              >
                Checkout
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Checkout modal */}
      {checkoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setCheckoutOpen(false)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 sticky top-0 bg-white rounded-t-2xl">
              <h2 className="text-lg font-bold text-slate-800">Complete Sale</h2>
              <button onClick={() => setCheckoutOpen(false)} className="p-2 rounded-lg hover:bg-slate-100">
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <Select
                label="Customer"
                value={selectedCustomer}
                onChange={setSelectedCustomer}
                options={[
                  { value: 'walkin', label: 'Walk-in Customer' },
                  ...customers.map((c) => ({
                    value: c.id,
                    label: c.company ? `${c.name} (${c.company})` : c.name,
                  })),
                ]}
              />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Tax Rate (%)</label>
                  <input
                    type="number"
                    value={taxRate}
                    onChange={(e) => setTaxRate(e.target.value)}
                    step="0.01"
                    className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Discount ($)</label>
                  <input
                    type="number"
                    value={discount}
                    onChange={(e) => setDiscount(e.target.value)}
                    step="0.01"
                    className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800"
                  />
                </div>
              </div>
              <Select
                label="Payment Method"
                value={paymentMethod}
                onChange={setPaymentMethod}
                options={[
                  { value: 'cash', label: 'Cash' },
                  { value: 'card', label: 'Card' },
                  { value: 'transfer', label: 'Bank Transfer' },
                  { value: 'credit', label: 'Store Credit' },
                ]}
              />
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Notes (optional)</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800 resize-none"
                  placeholder="Add any order notes..."
                />
              </div>

              {/* Order summary */}
              <div className="bg-slate-50 rounded-xl p-4 space-y-1.5">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Subtotal</span>
                  <span className="text-slate-700">{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Tax</span>
                  <span className="text-slate-700">{formatCurrency(taxAmount)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Discount</span>
                  <span className="text-slate-700">-{formatCurrency(discountAmount)}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-200">
                  <span className="font-bold text-slate-800">Total Due</span>
                  <span className="font-bold text-emerald-600 text-lg">{formatCurrency(total)}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="secondary" onClick={() => setCheckoutOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleCheckout} disabled={processing} className="flex-1">
                  {processing ? 'Processing...' : 'Confirm Sale'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
