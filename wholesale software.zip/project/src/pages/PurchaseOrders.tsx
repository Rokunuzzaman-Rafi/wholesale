import { useEffect, useState } from 'react';
import {
  Plus,
  Search,
  Trash2,
  ClipboardList,
  X,
  CheckCircle,
  Package,
  Truck,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Product, Supplier, PurchaseOrder, PurchaseOrderItem, POCartItem } from '@/types';
import { Select, Button, formatCurrency, formatDate } from '@/components/ui';

const statusColors: Record<string, string> = {
  draft: 'bg-slate-100 text-slate-600',
  ordered: 'bg-blue-100 text-blue-700',
  received: 'bg-emerald-100 text-emerald-700',
  cancelled: 'bg-red-100 text-red-700',
};

const statusIcons: Record<string, typeof ClipboardList> = {
  draft: ClipboardList,
  ordered: Truck,
  received: CheckCircle,
  cancelled: X,
};

export default function PurchaseOrders() {
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [createOpen, setCreateOpen] = useState(false);
  const [detailOrder, setDetailOrder] = useState<PurchaseOrder | null>(null);
  const [detailItems, setDetailItems] = useState<PurchaseOrderItem[]>([]);
  const [poCart, setPoCart] = useState<POCartItem[]>([]);
  const [selectedSupplier, setSelectedSupplier] = useState('');
  const [taxRate, setTaxRate] = useState('0');
  const [shipping, setShipping] = useState('0');
  const [expectedDate, setExpectedDate] = useState('');
  const [notes, setNotes] = useState('');
  const [productSearch, setProductSearch] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const [poRes, prodRes, supRes] = await Promise.all([
      supabase
        .from('purchase_orders')
        .select('*, supplier:suppliers(*)')
        .order('created_at', { ascending: false }),
      supabase.from('products').select('*').order('name', { ascending: true }),
      supabase.from('suppliers').select('*').order('name', { ascending: true }),
    ]);
    if (poRes.data) setPurchaseOrders(poRes.data as PurchaseOrder[]);
    if (prodRes.data) setProducts(prodRes.data as Product[]);
    if (supRes.data) setSuppliers(supRes.data as Supplier[]);
    setLoading(false);
  };

  const filtered = purchaseOrders.filter((po) => {
    const matchesSearch =
      po.po_number.toLowerCase().includes(search.toLowerCase()) ||
      (po.supplier?.name || '').toLowerCase().includes(search.toLowerCase());
    const matchesStatus = filterStatus === 'all' || po.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
      p.sku.toLowerCase().includes(productSearch.toLowerCase())
  );

  const addToCart = (product: Product) => {
    const existing = poCart.find((c) => c.product.id === product.id);
    if (existing) {
      setPoCart(poCart.map((c) => (c.product.id === product.id ? { ...c, quantity: c.quantity + 1 } : c)));
    } else {
      setPoCart([...poCart, { product, quantity: 1, unit_cost: product.cost_price }]);
    }
  };

  const updateQty = (productId: string, qty: number) => {
    setPoCart(poCart.map((c) => (c.product.id === productId ? { ...c, quantity: Math.max(0, qty) } : c)).filter((c) => c.quantity > 0));
  };

  const updateCost = (productId: string, cost: number) => {
    setPoCart(poCart.map((c) => (c.product.id === productId ? { ...c, unit_cost: Math.max(0, cost) } : c)));
  };

  const removeFromCart = (productId: string) => {
    setPoCart(poCart.filter((c) => c.product.id !== productId));
  };

  const subtotal = poCart.reduce((sum, c) => sum + c.quantity * c.unit_cost, 0);
  const taxAmount = (subtotal * (parseFloat(taxRate) || 0)) / 100;
  const shippingAmount = parseFloat(shipping) || 0;
  const total = subtotal + taxAmount + shippingAmount;

  const openCreate = () => {
    setPoCart([]);
    setSelectedSupplier(suppliers[0]?.id || '');
    setTaxRate('0');
    setShipping('0');
    setExpectedDate('');
    setNotes('');
    setProductSearch('');
    setCreateOpen(true);
  };

  const handleCreate = async (status: 'draft' | 'ordered') => {
    if (poCart.length === 0) return;
    setSaving(true);

    const { data: poNum } = await supabase.rpc('generate_po_number');
    if (!poNum) { alert('Failed to generate PO number'); setSaving(false); return; }

    const poData = {
      po_number: poNum,
      supplier_id: selectedSupplier || null,
      subtotal,
      tax_rate: parseFloat(taxRate) || 0,
      tax_amount: taxAmount,
      shipping: shippingAmount,
      total,
      status,
      notes,
      expected_date: expectedDate || null,
    };

    const { data: poResult, error: poError } = await supabase
      .from('purchase_orders')
      .insert(poData)
      .select('id')
      .single();

    if (poError || !poResult) { alert('Error: ' + (poError?.message || 'Unknown')); setSaving(false); return; }

    const items = poCart.map((c) => ({
      po_id: poResult.id,
      product_id: c.product.id,
      product_name: c.product.name,
      quantity: c.quantity,
      unit_cost: c.unit_cost,
      line_total: c.quantity * c.unit_cost,
    }));

    const { error: itemsError } = await supabase.from('purchase_order_items').insert(items);
    if (itemsError) { alert('Error: ' + itemsError.message); setSaving(false); return; }

    setSaving(false);
    setCreateOpen(false);
    fetchData();
  };

  const receiveGoods = async (po: PurchaseOrder) => {
    const { data: items } = await supabase
      .from('purchase_order_items')
      .select('*')
      .eq('po_id', po.id);

    if (!items || items.length === 0) return;

    for (const item of items as PurchaseOrderItem[]) {
      if (item.product_id) {
        const { data: product } = await supabase
          .from('products')
          .select('stock_qty, cost_price')
          .eq('id', item.product_id)
          .maybeSingle();

        if (product) {
          const newStock = Number(product.stock_qty) + Number(item.quantity);
          await supabase
            .from('products')
            .update({ stock_qty: newStock, cost_price: Number(item.unit_cost) })
            .eq('id', item.product_id);
        }
      }
    }

    await supabase.from('purchase_orders').update({ status: 'received' }).eq('id', po.id);
    setDetailOrder(null);
    fetchData();
  };

  const cancelPO = async (po: PurchaseOrder) => {
    await supabase.from('purchase_orders').update({ status: 'cancelled' }).eq('id', po.id);
    setDetailOrder(null);
    fetchData();
  };

  const viewDetail = async (po: PurchaseOrder) => {
    setDetailOrder(po);
    const { data } = await supabase.from('purchase_order_items').select('*').eq('po_id', po.id);
    if (data) setDetailItems(data as PurchaseOrderItem[]);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Purchase Orders</h1>
          <p className="text-slate-500 mt-1">Order stock from your suppliers and factories</p>
        </div>
        <Button onClick={openCreate} disabled={suppliers.length === 0}>
          <Plus className="w-4 h-4 inline mr-1" /> New Purchase Order
        </Button>
      </div>

      {suppliers.length === 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-700">
          You need to add at least one supplier before creating a purchase order.
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by PO number or supplier..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none text-slate-800"
          />
        </div>
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none bg-white text-slate-800"
        >
          <option value="all">All Status</option>
          <option value="draft">Draft</option>
          <option value="ordered">Ordered</option>
          <option value="received">Received</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">PO #</th>
                <th className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider hidden md:table-cell">Date</th>
                <th className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Supplier</th>
                <th className="text-right px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider hidden sm:table-cell">Items</th>
                <th className="text-right px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Total</th>
                <th className="text-center px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center">
                    <ClipboardList className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                    <p className="text-slate-400">No purchase orders found</p>
                  </td>
                </tr>
              ) : (
                filtered.map((po) => (
                  <tr key={po.id} onClick={() => viewDetail(po)} className="hover:bg-slate-50 transition-colors cursor-pointer">
                    <td className="px-6 py-4 text-sm font-medium text-blue-600">{po.po_number}</td>
                    <td className="px-6 py-4 text-sm text-slate-500 hidden md:table-cell">{formatDate(po.created_at)}</td>
                    <td className="px-6 py-4 text-sm font-medium text-slate-700">{po.supplier?.name || 'N/A'}</td>
                    <td className="px-6 py-4 text-sm text-slate-500 text-right hidden sm:table-cell">
                      {po.purchase_order_items?.length || '—'}
                    </td>
                    <td className="px-6 py-4 text-sm font-bold text-slate-800 text-right">{formatCurrency(Number(po.total))}</td>
                    <td className="px-6 py-4 text-center">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium capitalize ${statusColors[po.status] || 'bg-slate-100 text-slate-600'}`}>
                        {po.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create PO modal */}
      {createOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setCreateOpen(false)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 sticky top-0 bg-white rounded-t-2xl z-10">
              <h2 className="text-lg font-bold text-slate-800">New Purchase Order</h2>
              <button onClick={() => setCreateOpen(false)} className="p-2 rounded-lg hover:bg-slate-100">
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Select
                  label="Supplier"
                  value={selectedSupplier}
                  onChange={setSelectedSupplier}
                  options={suppliers.map((s) => ({
                    value: s.id,
                    label: s.company ? `${s.name} (${s.company})` : s.name,
                  }))}
                />
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Expected Date</label>
                  <input
                    type="date"
                    value={expectedDate}
                    onChange={(e) => setExpectedDate(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800"
                  />
                </div>
              </div>

              {/* Product search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search products to add to order..."
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800"
                />
              </div>

              {productSearch && (
                <div className="border border-slate-200 rounded-xl max-h-40 overflow-y-auto divide-y divide-slate-100">
                  {filteredProducts.slice(0, 5).map((p) => (
                    <button
                      key={p.id}
                      onClick={() => { addToCart(p); setProductSearch(''); }}
                      className="w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center justify-between"
                    >
                      <div>
                        <span className="text-sm font-medium text-slate-700">{p.name}</span>
                        <span className="text-xs text-slate-400 ml-2">{p.sku}</span>
                      </div>
                      <span className="text-sm text-slate-500">Stock: {p.stock_qty} {p.unit}</span>
                    </button>
                  ))}
                </div>
              )}

              {/* Cart items */}
              {poCart.length > 0 && (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-slate-50 border-b border-slate-200">
                      <tr>
                        <th className="text-left px-4 py-2 text-xs font-semibold text-slate-500">Product</th>
                        <th className="text-center px-4 py-2 text-xs font-semibold text-slate-500">Qty</th>
                        <th className="text-right px-4 py-2 text-xs font-semibold text-slate-500">Unit Cost</th>
                        <th className="text-right px-4 py-2 text-xs font-semibold text-slate-500">Total</th>
                        <th className="px-4 py-2"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {poCart.map((c) => (
                        <tr key={c.product.id}>
                          <td className="px-4 py-2.5 text-sm text-slate-700">{c.product.name}</td>
                          <td className="px-4 py-2.5">
                            <input
                              type="number"
                              value={c.quantity}
                              onChange={(e) => updateQty(c.product.id, parseInt(e.target.value) || 0)}
                              className="w-16 text-center text-sm border border-slate-200 rounded-lg py-1 outline-none focus:ring-1 focus:ring-emerald-500"
                            />
                          </td>
                          <td className="px-4 py-2.5">
                            <input
                              type="number"
                              step="0.01"
                              value={c.unit_cost}
                              onChange={(e) => updateCost(c.product.id, parseFloat(e.target.value) || 0)}
                              className="w-24 text-right text-sm border border-slate-200 rounded-lg py-1 outline-none focus:ring-1 focus:ring-emerald-500"
                            />
                          </td>
                          <td className="px-4 py-2.5 text-sm font-medium text-slate-700 text-right">
                            {formatCurrency(c.quantity * c.unit_cost)}
                          </td>
                          <td className="px-4 py-2.5">
                            <button onClick={() => removeFromCart(c.product.id)} className="text-red-400 hover:text-red-600">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Tax Rate (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={taxRate}
                    onChange={(e) => setTaxRate(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Shipping ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={shipping}
                    onChange={(e) => setShipping(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800"
                  />
                </div>
                <div className="flex items-end">
                  <div className="w-full bg-slate-50 rounded-lg px-4 py-2.5">
                    <p className="text-xs text-slate-400">Total</p>
                    <p className="font-bold text-emerald-600">{formatCurrency(total)}</p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Notes</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800 resize-none"
                  placeholder="Order notes..."
                />
              </div>

              <div className="flex gap-3 pt-2">
                <Button variant="secondary" onClick={() => setCreateOpen(false)} className="flex-1">Cancel</Button>
                <Button variant="secondary" onClick={() => handleCreate('draft')} disabled={saving || poCart.length === 0} className="flex-1">
                  Save Draft
                </Button>
                <Button onClick={() => handleCreate('ordered')} disabled={saving || poCart.length === 0} className="flex-1">
                  {saving ? 'Saving...' : 'Place Order'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Detail modal */}
      {detailOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setDetailOrder(null)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 sticky top-0 bg-white rounded-t-2xl">
              <div>
                <h2 className="text-lg font-bold text-slate-800">{detailOrder.po_number}</h2>
                <p className="text-sm text-slate-400">{formatDate(detailOrder.created_at)}</p>
              </div>
              <button onClick={() => setDetailOrder(null)} className="p-2 rounded-lg hover:bg-slate-100">
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400 uppercase tracking-wide">Supplier</p>
                  <p className="font-medium text-slate-800">{detailOrder.supplier?.name || 'N/A'}</p>
                  {detailOrder.supplier?.company && <p className="text-sm text-slate-500">{detailOrder.supplier.company}</p>}
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-400 uppercase tracking-wide">Status</p>
                  <span className={`px-2.5 py-1 rounded-full text-xs font-medium capitalize ${statusColors[detailOrder.status] || 'bg-slate-100 text-slate-600'}`}>
                    {detailOrder.status}
                  </span>
                </div>
              </div>

              {detailOrder.expected_date && (
                <p className="text-sm text-slate-500">
                  Expected: {formatDate(detailOrder.expected_date)}
                </p>
              )}

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="text-left px-4 py-2.5 text-xs font-semibold text-slate-500">Product</th>
                      <th className="text-center px-4 py-2.5 text-xs font-semibold text-slate-500">Qty</th>
                      <th className="text-right px-4 py-2.5 text-xs font-semibold text-slate-500">Cost</th>
                      <th className="text-right px-4 py-2.5 text-xs font-semibold text-slate-500">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {detailItems.map((item) => (
                      <tr key={item.id}>
                        <td className="px-4 py-2.5 text-sm text-slate-700">{item.product_name}</td>
                        <td className="px-4 py-2.5 text-sm text-slate-500 text-center">{item.quantity}</td>
                        <td className="px-4 py-2.5 text-sm text-slate-500 text-right">{formatCurrency(Number(item.unit_cost))}</td>
                        <td className="px-4 py-2.5 text-sm font-medium text-slate-700 text-right">{formatCurrency(Number(item.line_total))}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-sm"><span className="text-slate-500">Subtotal</span><span className="text-slate-700">{formatCurrency(Number(detailOrder.subtotal))}</span></div>
                <div className="flex justify-between text-sm"><span className="text-slate-500">Tax ({detailOrder.tax_rate}%)</span><span className="text-slate-700">{formatCurrency(Number(detailOrder.tax_amount))}</span></div>
                <div className="flex justify-between text-sm"><span className="text-slate-500">Shipping</span><span className="text-slate-700">{formatCurrency(Number(detailOrder.shipping))}</span></div>
                <div className="flex justify-between pt-2 border-t border-slate-100"><span className="font-bold text-slate-800">Total</span><span className="font-bold text-emerald-600 text-lg">{formatCurrency(Number(detailOrder.total))}</span></div>
              </div>

              {detailOrder.notes && (
                <div className="bg-slate-50 rounded-xl p-4">
                  <p className="text-xs text-slate-400 uppercase tracking-wide mb-1">Notes</p>
                  <p className="text-sm text-slate-600">{detailOrder.notes}</p>
                </div>
              )}

              {detailOrder.status === 'ordered' && (
                <div className="flex gap-3">
                  <Button variant="danger" onClick={() => cancelPO(detailOrder)} className="flex-1">Cancel Order</Button>
                  <Button onClick={() => receiveGoods(detailOrder)} className="flex-1">
                    <Package className="w-4 h-4 inline mr-1" /> Receive Goods
                  </Button>
                </div>
              )}
              {detailOrder.status === 'draft' && (
                <div className="flex gap-3">
                  <Button variant="danger" onClick={() => cancelPO(detailOrder)} className="flex-1">Cancel</Button>
                  <Button onClick={async () => {
                    await supabase.from('purchase_orders').update({ status: 'ordered' }).eq('id', detailOrder.id);
                    setDetailOrder(null);
                    fetchData();
                  }} className="flex-1">Place Order</Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
