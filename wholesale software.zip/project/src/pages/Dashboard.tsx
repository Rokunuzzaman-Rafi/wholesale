import { useEffect, useState } from 'react';
import {
  DollarSign,
  ShoppingBag,
  Package,
  AlertTriangle,
  TrendingUp,
  ArrowRight,
  Truck,
  Wallet,
  Factory,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Product, Order, PurchaseOrder } from '@/types';
import { formatCurrency, formatDate } from '@/components/ui';
import type { PageId } from '@/components/Layout';

interface DashboardProps {
  onNavigate: (page: PageId) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const [todaySales, setTodaySales] = useState(0);
  const [todayOrderCount, setTodayOrderCount] = useState(0);
  const [totalProducts, setTotalProducts] = useState(0);
  const [lowStockProducts, setLowStockProducts] = useState<Product[]>([]);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [pendingPOs, setPendingPOs] = useState<PurchaseOrder[]>([]);
  const [todayExpenses, setTodayExpenses] = useState(0);
  const [supplierCount, setSupplierCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayISO = today.toISOString();
    const todayDate = today.toISOString().split('T')[0];

    const [ordersRes, productsRes, lowStockRes, recentRes, poRes, expensesRes, suppliersRes] = await Promise.all([
      supabase.from('orders').select('total, created_at').gte('created_at', todayISO).eq('status', 'completed'),
      supabase.from('products').select('id', { count: 'exact', head: true }),
      supabase.from('products').select('*').filter('stock_qty', 'lte', 'reorder_level').order('stock_qty', { ascending: true }).limit(5),
      supabase.from('orders').select('*, customer:customers(*)').order('created_at', { ascending: false }).limit(5),
      supabase.from('purchase_orders').select('*, supplier:suppliers(*)').in('status', ['draft', 'ordered']).order('created_at', { ascending: false }).limit(5),
      supabase.from('expenses').select('amount').gte('date', todayDate),
      supabase.from('suppliers').select('id', { count: 'exact', head: true }),
    ]);

    if (ordersRes.data) {
      const sales = ordersRes.data.reduce((sum, o) => sum + Number(o.total), 0);
      setTodaySales(sales);
      setTodayOrderCount(ordersRes.data.length);
    }
    if (productsRes.count !== null) setTotalProducts(productsRes.count);
    if (lowStockRes.data) setLowStockProducts(lowStockRes.data as Product[]);
    if (recentRes.data) setRecentOrders(recentRes.data as Order[]);
    if (poRes.data) setPendingPOs(poRes.data as PurchaseOrder[]);
    if (expensesRes.data) {
      const exp = expensesRes.data.reduce((sum, e) => sum + Number(e.amount), 0);
      setTodayExpenses(exp);
    }
    if (suppliersRes.count !== null) setSupplierCount(suppliersRes.count);
    setLoading(false);
  };

  const stats = [
    { label: "Today's Sales", value: formatCurrency(todaySales), icon: DollarSign, color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { label: "Today's Orders", value: todayOrderCount.toString(), icon: ShoppingBag, color: 'text-blue-500', bg: 'bg-blue-50' },
    { label: 'Total Products', value: totalProducts.toString(), icon: Package, color: 'text-amber-500', bg: 'bg-amber-50' },
    { label: 'Low Stock Items', value: lowStockProducts.length.toString(), icon: AlertTriangle, color: 'text-red-500', bg: 'bg-red-50' },
    { label: "Today's Expenses", value: formatCurrency(todayExpenses), icon: Wallet, color: 'text-orange-500', bg: 'bg-orange-50' },
    { label: 'Pending POs', value: pendingPOs.length.toString(), icon: Truck, color: 'text-cyan-500', bg: 'bg-cyan-50' },
    { label: 'Suppliers', value: supplierCount.toString(), icon: Factory, color: 'text-indigo-500', bg: 'bg-indigo-50' },
    { label: 'Net Today', value: formatCurrency(todaySales - todayExpenses), icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Dashboard</h1>
        <p className="text-slate-500 mt-1">Overview of your wholesale business</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white rounded-2xl p-5 border border-slate-200 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-12 h-12 rounded-xl ${stat.bg} flex items-center justify-center`}>
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
              <p className="text-xl lg:text-2xl font-bold text-slate-800">{stat.value}</p>
              <p className="text-sm text-slate-500 mt-1">{stat.label}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Low stock alert */}
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              <h2 className="font-bold text-slate-800">Low Stock Alerts</h2>
            </div>
            <button onClick={() => onNavigate('products')} className="text-sm text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1">
              View all <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          <div className="divide-y divide-slate-100">
            {lowStockProducts.length === 0 ? (
              <p className="px-6 py-8 text-sm text-slate-400 text-center">All products are well stocked</p>
            ) : (
              lowStockProducts.map((p) => (
                <div key={p.id} className="flex items-center justify-between px-6 py-3">
                  <div>
                    <p className="font-medium text-slate-800 text-sm">{p.name}</p>
                    <p className="text-xs text-slate-400">{p.sku}</p>
                  </div>
                  <div className="text-right">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${p.stock_qty <= 0 ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}`}>
                      {p.stock_qty} {p.unit} left
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent orders */}
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-500" />
              <h2 className="font-bold text-slate-800">Recent Orders</h2>
            </div>
            <button onClick={() => onNavigate('orders')} className="text-sm text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1">
              View all <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          <div className="divide-y divide-slate-100">
            {recentOrders.length === 0 ? (
              <p className="px-6 py-8 text-sm text-slate-400 text-center">No orders yet. Start a new sale!</p>
            ) : (
              recentOrders.map((o) => (
                <div key={o.id} className="flex items-center justify-between px-6 py-3">
                  <div>
                    <p className="font-medium text-slate-800 text-sm">{o.order_number}</p>
                    <p className="text-xs text-slate-400">{o.customer?.name || 'Walk-in'} · {formatDate(o.created_at)}</p>
                  </div>
                  <span className="font-semibold text-slate-800 text-sm">{formatCurrency(Number(o.total))}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Pending purchase orders */}
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden lg:col-span-2">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <Truck className="w-5 h-5 text-cyan-500" />
              <h2 className="font-bold text-slate-800">Pending Purchase Orders</h2>
            </div>
            <button onClick={() => onNavigate('purchase-orders')} className="text-sm text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1">
              View all <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          <div className="divide-y divide-slate-100">
            {pendingPOs.length === 0 ? (
              <p className="px-6 py-8 text-sm text-slate-400 text-center">No pending purchase orders</p>
            ) : (
              pendingPOs.map((po) => (
                <div key={po.id} className="flex items-center justify-between px-6 py-3">
                  <div>
                    <p className="font-medium text-slate-800 text-sm">{po.po_number}</p>
                    <p className="text-xs text-slate-400">{po.supplier?.name || 'N/A'} · {formatDate(po.created_at)}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-semibold text-slate-700 text-sm">{formatCurrency(Number(po.total))}</span>
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium capitalize ${
                      po.status === 'ordered' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {po.status}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
