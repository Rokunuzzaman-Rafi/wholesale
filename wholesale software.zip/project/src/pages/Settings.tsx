import { useEffect, useState } from 'react';
import { Save, Store, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Settings as SettingsType } from '@/types';
import { Input, Button } from '@/components/ui';

const currencies = [
  { value: 'USD', label: 'US Dollar ($)' },
  { value: 'EUR', label: 'Euro (€)' },
  { value: 'GBP', label: 'British Pound (£)' },
  { value: 'JPY', label: 'Japanese Yen (¥)' },
  { value: 'INR', label: 'Indian Rupee (₹)' },
  { value: 'CNY', label: 'Chinese Yuan (¥)' },
  { value: 'AED', label: 'UAE Dirham' },
  { value: 'AUD', label: 'Australian Dollar ($)' },
  { value: 'CAD', label: 'Canadian Dollar ($)' },
  { value: 'NGN', label: 'Nigerian Naira (₦)' },
];

export default function Settings() {
  const [settings, setSettings] = useState<SettingsType | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    business_name: '',
    currency: 'USD',
    default_tax_rate: '0',
    tax_enabled: false,
    phone: '',
    email: '',
    address: '',
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    const { data } = await supabase.from('settings').select('*').maybeSingle();
    if (data) {
      setSettings(data as SettingsType);
      setForm({
        business_name: data.business_name,
        currency: data.currency,
        default_tax_rate: String(data.default_tax_rate),
        tax_enabled: data.tax_enabled,
        phone: data.phone,
        email: data.email,
        address: data.address,
      });
    }
    setLoading(false);
  };

  const handleSave = async () => {
    setSaving(true);
    const payload = {
      business_name: form.business_name.trim() || 'My Wholesale Business',
      currency: form.currency,
      default_tax_rate: parseFloat(form.default_tax_rate) || 0,
      tax_enabled: form.tax_enabled,
      phone: form.phone.trim(),
      email: form.email.trim(),
      address: form.address.trim(),
      updated_at: new Date().toISOString(),
    };

    if (settings) {
      const { error } = await supabase.from('settings').update(payload).eq('id', settings.id);
      if (error) { alert('Error: ' + error.message); setSaving(false); return; }
    } else {
      const { error } = await supabase.from('settings').insert(payload);
      if (error) { alert('Error: ' + error.message); setSaving(false); return; }
    }

    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
    fetchSettings();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Settings</h1>
        <p className="text-slate-500 mt-1">Configure your business information and preferences</p>
      </div>

      {/* Business Info */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <Store className="w-5 h-5 text-emerald-500" />
          <h2 className="font-bold text-slate-800">Business Information</h2>
        </div>
        <Input label="Business Name" value={form.business_name} onChange={(v) => setForm({ ...form, business_name: v })} placeholder="e.g. ABC Wholesale Co." />
        <div className="grid grid-cols-2 gap-4">
          <Input label="Phone" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} placeholder="555-0100" />
          <Input label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} placeholder="business@example.com" />
        </div>
        <Input label="Address" value={form.address} onChange={(v) => setForm({ ...form, address: v })} placeholder="Business address" />
      </div>

      {/* Tax & Currency */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
        <h2 className="font-bold text-slate-800">Tax & Currency</h2>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">Currency</label>
          <select
            value={form.currency}
            onChange={(e) => setForm({ ...form, currency: e.target.value })}
            className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800 bg-white"
          >
            {currencies.map((c) => (
              <option key={c.value} value={c.value}>{c.label}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={form.tax_enabled}
              onChange={(e) => setForm({ ...form, tax_enabled: e.target.checked })}
              className="w-5 h-5 rounded border-slate-300 text-emerald-500 focus:ring-emerald-500"
            />
            <div>
              <span className="text-sm font-medium text-slate-700">Enable tax on sales</span>
              <p className="text-xs text-slate-400">Apply default tax rate to all new sales</p>
            </div>
          </label>
        </div>
        {form.tax_enabled && (
          <Input label="Default Tax Rate (%)" type="number" step="0.01" value={form.default_tax_rate} onChange={(v) => setForm({ ...form, default_tax_rate: v })} />
        )}
      </div>

      {/* Save button */}
      <div className="flex items-center gap-3">
        <Button onClick={handleSave} disabled={saving}>
          {saving ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin inline mr-1" />
              Saving...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 inline mr-1" /> Save Settings
            </>
          )}
        </Button>
        {saved && (
          <span className="flex items-center gap-1.5 text-sm text-emerald-600 font-medium">
            <CheckCircle className="w-4 h-4" /> Settings saved successfully
          </span>
        )}
      </div>
    </div>
  );
}
