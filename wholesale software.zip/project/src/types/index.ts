export interface Product {
  id: string;
  sku: string;
  name: string;
  category: string;
  unit: string;
  cost_price: number;
  sell_price: number;
  stock_qty: number;
  reorder_level: number;
  created_at: string;
}

export interface Customer {
  id: string;
  name: string;
  company: string;
  phone: string;
  email: string;
  address: string;
  created_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string | null;
  product_name: string;
  quantity: number;
  unit_price: number;
  line_total: number;
}

export interface Order {
  id: string;
  order_number: string;
  customer_id: string | null;
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  discount: number;
  total: number;
  payment_method: string;
  status: string;
  notes: string;
  created_at: string;
  order_items?: OrderItem[];
  customer?: Customer | null;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Supplier {
  id: string;
  name: string;
  company: string;
  phone: string;
  email: string;
  address: string;
  payment_terms: string;
  notes: string;
  created_at: string;
}

export interface PurchaseOrderItem {
  id: string;
  po_id: string;
  product_id: string | null;
  product_name: string;
  quantity: number;
  unit_cost: number;
  line_total: number;
}

export interface PurchaseOrder {
  id: string;
  po_number: string;
  supplier_id: string | null;
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  shipping: number;
  total: number;
  status: string;
  notes: string;
  expected_date: string | null;
  created_at: string;
  supplier?: Supplier | null;
  purchase_order_items?: PurchaseOrderItem[];
}

export interface Expense {
  id: string;
  category: string;
  description: string;
  amount: number;
  date: string;
  created_at: string;
}

export interface Settings {
  id: string;
  business_name: string;
  currency: string;
  default_tax_rate: number;
  tax_enabled: boolean;
  phone: string;
  email: string;
  address: string;
  updated_at: string;
}

export interface POCartItem {
  product: Product;
  quantity: number;
  unit_cost: number;
}
