import { useState } from 'react';
import {
  LayoutDashboard,
  Package,
  Users,
  ShoppingCart,
  Receipt,
  Store,
  Menu,
  Factory,
  ClipboardList,
  BarChart3,
  Wallet,
  Settings,
} from 'lucide-react';

export type PageId =
  | 'dashboard'
  | 'products'
  | 'customers'
  | 'pos'
  | 'orders'
  | 'suppliers'
  | 'purchase-orders'
  | 'reports'
  | 'expenses'
  | 'settings';

interface NavItem {
  id: PageId;
  label: string;
  icon: typeof LayoutDashboard;
}

interface NavSection {
  label: string;
  items: NavItem[];
}

const navSections: NavSection[] = [
  {
    label: 'Overview',
    items: [{ id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard }],
  },
  {
    label: 'Sales',
    items: [
      { id: 'pos', label: 'New Sale', icon: ShoppingCart },
      { id: 'orders', label: 'Orders', icon: Receipt },
      { id: 'customers', label: 'Customers', icon: Users },
    ],
  },
  {
    label: 'Inventory',
    items: [{ id: 'products', label: 'Products', icon: Package }],
  },
  {
    label: 'Procurement',
    items: [
      { id: 'suppliers', label: 'Suppliers', icon: Factory },
      { id: 'purchase-orders', label: 'Purchase Orders', icon: ClipboardList },
    ],
  },
  {
    label: 'Finance',
    items: [
      { id: 'reports', label: 'Reports', icon: BarChart3 },
      { id: 'expenses', label: 'Expenses', icon: Wallet },
    ],
  },
  {
    label: 'System',
    items: [{ id: 'settings', label: 'Settings', icon: Settings }],
  },
];

interface LayoutProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  children: React.ReactNode;
}

export default function Layout({ currentPage, onNavigate, children }: LayoutProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNavigate = (page: PageId) => {
    onNavigate(page);
    setMobileOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 left-0 z-50 h-screen w-64 bg-slate-900 text-white flex flex-col transition-transform duration-300 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex items-center gap-3 px-6 py-6 border-b border-slate-700">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-emerald-500">
            <Store className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">WholesalePOS</h1>
            <p className="text-xs text-slate-400">Business Manager</p>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 overflow-y-auto space-y-4">
          {navSections.map((section) => (
            <div key={section.label}>
              <p className="px-4 mb-1 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {section.label}
              </p>
              <div className="space-y-1">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const active = currentPage === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleNavigate(item.id)}
                      className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                        active
                          ? 'bg-emerald-500 text-white'
                          : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="px-6 py-4 border-t border-slate-700">
          <p className="text-xs text-slate-500">Wholesale POS v2.0</p>
        </div>
      </aside>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile header */}
        <header className="lg:hidden flex items-center justify-between px-4 py-4 bg-white border-b border-slate-200 sticky top-0 z-30">
          <button
            onClick={() => setMobileOpen(true)}
            className="p-2 rounded-lg hover:bg-slate-100"
          >
            <Menu className="w-6 h-6 text-slate-700" />
          </button>
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-emerald-500" />
            <span className="font-bold text-slate-800">WholesalePOS</span>
          </div>
          <div className="w-10" />
        </header>

        <main className="flex-1 p-4 lg:p-8 max-w-7xl mx-auto w-full">{children}</main>
      </div>
    </div>
  );
}
