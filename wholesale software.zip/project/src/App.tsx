import { useState } from 'react';
import Layout, { PageId } from '@/components/Layout';
import Dashboard from '@/pages/Dashboard';
import Products from '@/pages/Products';
import Customers from '@/pages/Customers';
import POS from '@/pages/POS';
import Orders from '@/pages/Orders';
import Suppliers from '@/pages/Suppliers';
import PurchaseOrders from '@/pages/PurchaseOrders';
import Reports from '@/pages/Reports';
import Expenses from '@/pages/Expenses';
import Settings from '@/pages/Settings';

function App() {
  const [page, setPage] = useState<PageId>('dashboard');

  return (
    <Layout currentPage={page} onNavigate={setPage}>
      {page === 'dashboard' && <Dashboard onNavigate={setPage} />}
      {page === 'pos' && <POS onNavigate={setPage} />}
      {page === 'products' && <Products />}
      {page === 'customers' && <Customers />}
      {page === 'orders' && <Orders />}
      {page === 'suppliers' && <Suppliers />}
      {page === 'purchase-orders' && <PurchaseOrders />}
      {page === 'reports' && <Reports />}
      {page === 'expenses' && <Expenses />}
      {page === 'settings' && <Settings />}
    </Layout>
  );
}

export default App;
